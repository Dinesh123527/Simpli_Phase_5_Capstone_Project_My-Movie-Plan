package com.example.capstone.movie.exceptions;

public class AdminUserExistException extends Exception{
	private static final long serialVersionUID = 1L;
}
