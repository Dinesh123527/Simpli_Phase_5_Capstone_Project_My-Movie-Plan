package com.example.capstone.movie.exceptions;

public class UserExistException extends Exception {
	private static final long serialVersionUID = 1L;
}
